export const language = {

    'WTM_MASTERY_TOOLTIP1':"Weapon Masteries represent your use with a weapon and weapons of that type.",
    'WTM_MASTERY_TOOLTIP2':"Mastery with a weapon is increased primarily by attacking with it, and secondarily by killing enemies.",
    'WTM_MASTERY_TOOLTIP3':"Hover over different elements to learn more about weapon masteries",
    
    'WTM_UNIQ_TOOLTIP1':"A weapon's <span class='text-success'>Uniqueness</span> determines how much training can be gotten out of it. Rare and unusual weapons are more unique.",
    'WTM_UNIQ_TOOLTIP2':"A weapon's uniqueness is unrelated to its strength.",



    'WTM_CHECKTYPE':"Weapon Types & Mastery",
    'WTM_TYPELOCKEDCONSTR':'Construct combat furniture in <span class="construction-victory">Construction</span> to unlock',

    'WTM_HBOW2': "Unlock the Killshot Special Attack",
    'WTM_HBOW3': "+5% Chance To Double Loot in Combat when fighting Slayer Task monsters",
    'WTM_HBOW4': "+10% chance to trigger Killshot",
    'WTM_HBOW42': "+25% critical hit multiplier when fighting Slayer Task monsters",
    'WTM_ARTF3': "Unlock the Pandora's Spark Special Attack",




    'WTM_HBOW0': "+20% critical hit multiplier",
    'WTM_HBOW1': "Unlock the Power Shot Special Attack",


    'WTM_STAVES1': "Attune to an element at the Start of the Fight",
    'WTM_STAVES2': "Unlock a boon based on attuned element",
    'WTM_STAVES3': "Attuning to an element surrounds you in a protective Aura",
    'WTM_STAVES4': "Unlock a boon based on attuned element",
    'WTM_STAVES5': "Unlock a powerful boon based on attuned element",


    'WTM_THRUST1': "Unlock Dueling Stance",
    'WTM_THRUST3': "Unlock the Practiced Lunge Special Attack",
    'WTM_THRUST32': "If your Shield slot is empty, double this type's bonuses.",
    'WTM_THRUST4': "If your Shield slot is empty, triple this level's bonuses and gain +10% chance to pierce enemy Resistance.",
    'WTM_THRUST5': "Chance to Parry when an enemy misses you based on defense values",
    'WTM_THRUST52': "+10% chance to inflict Disarm to enemy on Hit",

    'WTM_GREAT1': "20% Chance on Hit to inflict Intimidation",
    'WTM_GREAT2': "20% Chance on Hit to inflict Shaken",
    'WTM_GREAT3': "Unlock the Devastating Slice Special Attack",
    'WTM_GREAT32': "+5% chance to apply Intimidation when hitting a Shaken enemy",


    'WTM_GREAT4': "1% Chance on Hit, Being Hit, and Evading to inflict a random Fear Effect for 3 turns",
    'WTM_GREAT42': "+5% Max Hit and Total Resistance per Fear Effect on the enemy",
    'WTM_GREAT5': "At the Start of the Fight, inflict Intimidation and Shaken to the enemy for 3 turns.",
    'WTM_GREAT52': "+0.5% Accuracy and Max Hit per 8 Strength Skill Levels for each Fear effect on the enemy",

    'WTM_POLE2': "25% Chance to gain 1 stack of Certainty when evading an attack",
    'WTM_POLE21': "25% Chance to gain 1 stack of Swiftness when hitting with an attack",

    'WTM_POLE3': "Unlock the Whirling Manoeuvre Special Attack",
    'WTM_POLE32': "Gain 5 stacks of Poise and Swiftness at the Start of the Fight",
    'WTM_POLE4': "+25 Bonus to Slash, Stab, and Block Attack",
    'WTM_POLE42': "+25 Bonus to Melee, Magic, and Ranged Defence",

    'WTM_BLUNT2': "+25% chance to apply Dazed when hitting an enemy with Broken",
    'WTM_BLUNT3': "Unlocks the Concussive Smash Special Attack",
    'WTM_BLUNT4': "+10% chance to inflict Stun when hitting an enemy with Broken",
    'WTM_BLUNT5': "If Target is currently Stunned, +30% Damage Dealt",

    'WTM_DAGGER0': "+25 Stealth",
    'WTM_DAGGER2': "Apply Shrouded when critically hitting with an attack",
    'WTM_DAGGER3': "Unlocks the Blindside Special Attack",
    'WTM_DAGGER4': 'Shrouded grants +1.5% critical hit chance per 25 Stealth',
    'WTM_DAGGER5': "Shrouded grants -0.15s Flat Attack Interval per 25 Stealth",
    'WTM_DAGGER52': "+50 Stealth",

    'WTM_CURVED3': "Unlock the Mounted Strike Special Attack",
    'WTM_CURVED5': "Unlock Advantage",

    'WTM_HTH0': "+10% Reflect Damage against ranged attacks",
    'WTM_HTH1': "Can use certain gloves as weapons",
    'WTM_HTH12': "+15% Defence Level added as Flat Hidden Defence Levels and Total Resistance while unburdened",
    'WTM_HTH3': "+20% Defence Level added as Flat Hidden Defence Levels and Total Resistance while unburdened",
    'WTM_HTH32': 'Unlock the Channelled Palm Strike Special Attack',
    'WTM_HTH4': "+35% Chance to ignore Slow, Stun, Freeze, and Sleep when unburdened",
    'WTM_HTH42': "-0.40s Attack Interval when unburdened",
    'WTM_HTH5': "Unlock the Flowing Palm Wave Special Attack",
    'WTM_HTH52': "+50% HP Regen and -5s HP Regen Interval when unburdened",

    'WTM_AXES3': "Unlock the Bloodlust Special Attack",
    'WTM_AXES4': "Inflict Bloodlust and Hemorrhage at the start of the fight",
    'WTM_AXES42': "25% chance to inflict Hemorrhage on Hit while Target is Bleeding.",

    'WTM_AXES5': "+7.5% chance for both while enemy is bleeding",

    'WTM_BLUNT3': "Unlocks the Concussive Smash Special Attack.",

    'WTM_CROSS3': "Unlock the Take Aim Special Attack",
    'WTM_CROSS4': "Your first attack is an unavoidable critical hit",
    'WTM_CROSS5': "+15% Accuracy Rating while fighting Melee Enemies",
    'WTM_CROSS52': "+30% Ranged Max Hit while Enemy HP is ≥90%",

    'WTM_LBOW1': "+5% chance on hit to shoot an infused arrow on the enemy",
    'WTM_LBOW12': "While the enemy is afflicted by an infused arrow, +10% evasion chance",
    'WTM_LBOW3': "Unlock the Hail of Arrows Special Attack",
    'WTM_LBOW32': "+5% lifesteal per infused arrow on the enemy",
    'WTM_LBOW4': "Unlock new infused arrows",
    'WTM_LBOW42': "Hail of Arrows Strikes +2 times per Infused Arrow on the enemy",
    'WTM_LBOW5': "+100% Duration and damage cap to infused arrows",
    'WTM_LBOW52': "-0.10s attack interval per infused arrow on the enemy",
    'WTM_LBOW53': "Hail of Arrows strikes +10 times",

    'WTM_THROWN1': "Cannot use Special Attacks",
    'WTM_THROWN2': "Start each fight with a Volley",
    'WTM_THROWN3': "+15 Max stacks for Alacrity",
    'WTM_THROWN4': "During Volley, the enemy is Confused",
    'WTM_THROWN5': "+25% Max Hit and Accuracy Rating during Volley",
    'WTM_THROWN51': "Enemy has -50% Accuracy during Volley",
    'WTM_THROWN52': "Get The Drop at the start of the fight",

    'WTM_WANDS3': "Increase rune cost reduction of magic weapons",
    'WTM_WANDS4': "+1 All Defence Bonus per 4% of Damage Reduction",

    'WTM_EMTPY_EQUIP_NAME': 'Unarmed',
    'MODIFIER_DATA_increaseWeaponXPMelee': "${value}% Melee Weapon Mastery XP",
    'MODIFIER_DATA_increaseWeaponXPRanged': "${value}% Ranged Weapon Mastery XP",
    'MODIFIER_DATA_increaseWeaponXPMagic': "${value}% Magic Weapon Mastery XP",
    'MODIFIER_DATA_increaseWeaponXP': "${value}% Weapon Mastery XP",
    'MODIFIER_DATA_combatSkillXP': "${value}% Combat Skill XP",
    'MODIFIER_DATA_spoofIncreaseSkillXP': '${value}% Chance to Special Attacks granted by Weapon Types',
    'MODIFIER_DATA_fakeModifierAddTextDescToWepType': "Adds a new Special Attack to all weapons of this type",
    'MODIFIER_DATA_unlockParry': 'Grants Parry: Counter-attack on enemy Misses. Scales with Armor Defence and enemy Level',
    'MODIFIER_DATA_dodgeChancePer10000EnemyAccuracyRating': '${value}% chance to convert a successful enemy hit into a miss per 10,000 enemy Accuracy Rating',
    'MODIFIER_DATA_accuracyRatingPer10000Evasion': '${value}% Accuracy Rating per 10,000 Evasion',
    'MODIFIER_DATA_SummonQuickenAct': 'Summoning Familiar Attacks quicken attack by ${value}s',
    'MODIFIER_DATA_ExtraSummonHits': '${value} additional Summon attacks after every attack',
    'MODIFIER_DATA_slashingOnSummon': '${value}% of Slash Attack bonus added as Familiar damage',
    'MODIFIER_DATA_skillItemDoublingChanceGlobal': '${value}% Chance to Double Items in Skills',
    'MODIFIER_DATA_RandomUpSpellDamRune': 'Randomize Spell Damage and Rune Cost from 50% to 250% every cast',
    'MODIFIER_DATA_RandomRuneReduction': 'Decrease Minimum Random Rune Cost to 33%',
    'MODIFIER_DATA_RandomDamIncrease': 'Increase Maximum Random Spell Damage to 333%',
    'MODIFIER_DATA_runePreservationCap': "${value}% Rune preservation Cap",
    'MODIFIER_DATA_ammoPreservationCap': "${value}% Ammo preservation Cap",


    'MODIFIER_DATA_maxHitBasedOnMissingHitpoints': '${value}% Max Hit for each 10% of Hitpoints missing',
    'MODIFIER_DATA_fearDurationIncreaseChance': '${value}% chance to increase the length of fear effects inflicted by 1 turn',
    'MODIFIER_DATA_blessingChance': '${value}% chance to recieve three Triple-charged Buffs at the start of your turn',
    'MODIFIER_DATA_effectIgnoreChanceGlobal': '${value}% chance to ignore Negative Effects',
    'MODIFIER_DATA_ExtraPotencyEffects': 'Triple-triple-charge Pandora\'s Spark Effects',
    'MODIFIER_DATA_multiShotExtraShot': 'Hail of Arrows fires ${value} additional strikes',
    'MODIFIER_DATA_critChance25Stealth': "${value}% critical hit chance per 25 Stealth",
    'MODIFIER_DATA_doubleLootChance25Stealth': "${value}% Chance To Double Loot in Combat per 25 Stealth",
    'MODIFIER_DATA_flatAttackInterval100Stealth': "${value} Flat Attack Interval per 100 Stealth",
    'MODIFIER_DATA_damageTaken25Stealth': "${value}% less Damage taken per 25 Stealth",
    'MODIFIER_DATA_maxHit25Stealth': "${value}% Maximum Hit per 25 Stealth",
    'MODIFIER_DATA_critMult25Stealth': "${value}% critical hit multiplier per 25 Stealth",
    'MODIFIER_DATA_critDRPierce': "${value}% bypassed enemy Damage Reduction on critical hit",
    'MODIFIER_DATA_critChance10000Acc': "${value}% critical hit chance per 10000 Accuracy",
    'MODIFIER_DATA_critMult10000Acc': "${value}% critical hit multiplier per 10000 Accuracy",

















    'MODIFIER_TOOLTIP_THRUSTING1': '<div class="text-center"><span class="text-success font-weight-bold">Dueling Stance</span><br>Start Fight with 1 stack and on hit<br> Lose 1 stack on being hit<br> 1% bonus to Dodge Chance, Convert Miss into Hit, and Attack Interval per stack</div>',
    'MODIFIER_TOOLTIP_THRUSTING5': '<div class="text-center"><span class="text-success font-weight-bold">Parry</span><br>When an enemy misses you with an attack, you have a chance to perform a counterattack<br> Counterattack deals damage equal to your minimum hit on hit.</div>',
    'MODIFIER_TOOLTIP_THRUSTING52': '<div class="text-center"><span class="text-success font-weight-bold">Disarm</span><br>When you hit with an attack, you have a 10% chance (20% without a shield) to inflict Disarm to them <br> Disarm prevents them from attacking for 1 turn.</div>',


    'MODIFIER_TOOLTIP_GREAT1': '<div class="text-center"><span class="text-success font-weight-bold">Intimidation</span><br>Gives -10% Global Accuracy and Max Hit</div>',
    'MODIFIER_TOOLTIP_GREAT4': '<div class="text-center"><span class="text-success font-weight-bold">Terrify</span><br>10% chance to be Stunned and have attack interrupted</div>',
    'MODIFIER_TOOLTIP_GREAT5': '<div class="text-center"><span class="text-info font-weight-bold">Fear Effect</span><br>Fear, Terrify, Shaken, and Intimidate are considered Fear Effects</div>',

    'MODIFIER_TOOLTIP_POLE21': '<div class="text-center"><span class="text-success font-weight-bold">Poise</span><br>Gives +4% accuracy per stack (up to 25)</div>',
    'MODIFIER_TOOLTIP_POLE22': '<div class="text-center"><span class="text-success font-weight-bold">Swiftness</span><br>Gives +4% evasion per stack (up to 25)</div>',
    'MODIFIER_TOOLTIP_BLUNTS21': '<div class="text-center"><span class="text-success font-weight-bold">Broken</span><br>Gives -50% resistance</div>',
    'MODIFIER_TOOLTIP_BLUNTS22': '<div class="text-center"><span class="text-success font-weight-bold">Dazed</span><br>Gives +10% attack interval and stops them from evading, regenerating barrier, or using special attacks</div>',
    'MODIFIER_TOOLTIP_BLUNTS4': '<div class="text-center"><span class="text-success font-weight-bold">Stun</span><br>Cannot evade, attacks against Character deal 30% increased damage, also applies Stun Immunity on Application</div>',

    'MODIFIER_TOOLTIP_DAGGER2': '<div class="text-center"><span class="text-success font-weight-bold">Shrouded</span><br>Gives +2.5% critical hit muptiplier per 25 Stealth, lasts for 5 seconds or until the fight ends.</div>',


    'MODIFIER_TOOLTIP_HTH1': '<div class="text-center"><span class="text-info font-weight-bold">Unburdened</span><br>You are considered unburdened if your Platebody and Shield slots are both empty</div>',



    'MODIFIER_TOOLTIP_CURVED5': '<div class="text-center"><span class="text-success font-weight-bold">Advantage</span><br>Advantage gives stacking 5% Max Hit and Attack Interval to your Familiars per stack, up to 5 stacks<br>When at max stacks, instead spend stacks on hit by instructing your Companions to perform two Unavoidable Attacks</div>',
    'MODIFIER_TOOLTIP_POLEARMS3': '<div class="text-center"><span class="text-warning font-weight-bold">Whirling Manoeuvre (15%)</span><br>Whirl your polearm around, attacking multiple times for a small portion of your normal damage each.<br> While attacking, you gain +20% Reflect Damage and +20% Dodge Chance.</div>',
    'MODIFIER_TOOLTIP_AXES2': '<div class="text-center"><span class="text-success font-weight-bold">Bleed</span><br>Deals up to 100% damage dealt over the course of 10 seconds</div>',
    'MODIFIER_TOOLTIP_AXES3': `
<div class="text-center px-1" style="max-width: 280px;">
    <div class="text-warning font-weight-bold mb-1">Bloodlust (25%)</div>
    <div class="font-size-sm text-muted mb-2">Let out a bloodcurdling warcry. Inflict Bloodlust.</div>
    <div class="font-weight-bold text-success font-size-sm mb-1">Bloodlust (Max 10 stacks):</div>
    
    <div class="row no-gutters text-left">
        <div class="col-6 pr-1 border-right">
            <span class="text-warning font-weight-bold font-size-xs">On Player:</span>
            <div class="text-success">+5% Lifesteal</div>
            <div class="text-success">+4% Max Hit</div>
            <div class="text-success">+3% Flat Dmg against Bleed</div>
            <div class="text-success">-2% Atk Interval</div>
            <div class="text-danger">+1% Self Dmg</div>
        </div>
                <div class="col-6 pl-2">
            <span class="text-warning font-weight-bold font-size-xs">On enemy:</span>
            <div class="text-success">+5% Bleed Taken</div>
            <div class="text-success">-4% Max Hit</div>
            <div class="text-success">-3% Resistance</div>
            <div class="text-success">+2% Atk Interval</div>
        </div>
    </div>
</div>
`,
    'MODIFIER_TOOLTIP_AXES4': '<div class="text-center"><span class="text-success font-weight-bold">Hemorrhage</span><br>Deals up to 500% damage dealt over the course of 20 seconds</div>',
    'MODIFIER_TOOLTIP_HEAVY2': '<div class="text-center"><span class="text-warning font-weight-bold">Killshot (15%)</span><br>Deal damage equal to 100% to 200% of Enemy DR. On hit, apply 1 stack of Pinned.<br><div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Pinned</span><br>+1% Attack Interval and +1% Damage Taken per stack, up to 10. Lasts until end of the fight.</div>',
    'MODIFIER_TOOLTIP_HEAVY4': '<div class="text-center"><span class="text-success font-weight-bold">Vulnerability</span><br>+1% increased damage taken per stack, up to 25 stacks, flat -10% Flat Resistance</div>',
    'MODIFIER_TOOLTIP_HEAVY5': '<div class="text-center"><span class="text-success font-weight-bold">Hunter Stance</span><br>20% chance to ignore resistance, 10% critical hit chance and 50% critical hit multiplier<br> Effects weaken every time you are hit</div>',


    'MODIFIER_TOOLTIP_LIGHT2': '<div class="text-center"><span class="text-success font-weight-bold">Overextended</span><br>+25% DoT Damage taken for 3 turns/div>',
    'MODIFIER_TOOLTIP_LIGHT1': '<div class="text-center"><span class="text-info font-weight-bold">Arrow Infusions</span><br>All arrow Infusions last for 5 seconds<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Flame</span><br>Deal 6% of enemy\'s max health<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Poison</span><br>Deal 4% of enemy\'s max hp<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Tranq</span><br>+70% Interval on enemy<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Barbed</span><br>deal 200% normal damage to enemy</div>',
    'MODIFIER_TOOLTIP_LIGHT4': '<div class="text-center"><span class="text-success font-weight-bold">Toxic Smoke</span><br>Deal 5% of enemy\'s max health<br>Give enemy -25% Accuracy Rating and Damage Dealt<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Nullify</span><br>Deal 3% of enemy\'s max health <br>Give enemy +25% Damage Taken and inability to buff self</div>',
    'MODIFIER_TOOLTIP_THROWN1': '<div class="text-center"><span class="text-success font-weight-bold">Alacrity</span><br>-1% Attack Interval per stack, up to 15</div>',
    'MODIFIER_TOOLTIP_THROWN2': '<div class="text-center"><span class="text-success font-weight-bold">Volley</span><br>-50% to Attack Interval and Max Hit, and Accuracy. Lasts for 3 turns</div>',
    'MODIFIER_TOOLTIP_THROWN4': '<div class="text-center"><span class="text-success font-weight-bold">Confused</span><br>Take 2% of remaining HP dealt on a successful attack (once per turn, up to 10,000 damage)</div>',
    'MODIFIER_TOOLTIP_THROWN5': '<div class="text-center"><span class="text-success font-weight-bold">The Drop</span><br>+30% Max Hit for the first turn of battle</div>',

    'MODIFIER_TOOLTIP_STAVES1': '<div class="text-center"><span class="text-info font-weight-bold">Attuned Elmenets</span><br>Spells of the Attuned Element gain +25% Max Hit, all Attuned Elements have a 10% chance for an effect<br><div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Air</span><br>On Evade, Daze, Can\'t Special Attack or Evade, enemy, 3 turns<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Water</span><br>On Summon Attack, Heal, 150% of Max HP over 20s <div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Earth</span><br>On Being Hit, +50% of Current DR added as DR, for 3 turns<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Fire</span><br>On Hit, Burn, enemy</div>',
    'MODIFIER_TOOLTIP_STAVES2': '<div class="text-center"><span class="text-success font-weight-bold">Air</span><br>-15% Attack Interval which decays on hit and lasts 3 turns<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Water</span><br>Heal for 5% of your Current HP every 2 turns<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Earth</span><br>+5% Reflect Damage and 10% to inflict a 100% Bleed when Hit by an Attack<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Fire</span><br>Enemy takes +15% Damage from Burn</div>',
    'MODIFIER_TOOLTIP_STAVES3': '<div class="text-center"><span class="text-info font-weight-bold">Auras</span><br>All Auras have effects upon being hit and last 10 turns<br><span class="text-success font-weight-bold">Air</span><br>50% chance to stun the enemy<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Water</span><br>Slow enemy by 70%<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Earth</span><br>Gain protection against ranged, and bleed enemy for 100% damage<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Fire</span><br>Gain fire max hit, and burn enemy</div>',
    'MODIFIER_TOOLTIP_STAVES4': '<div class="text-center"><span class="text-success font-weight-bold">Air</span><br>On Crit, gain 1 stack of Concentration and 1 stack of Impact<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Water</span><br>On Hit, inflict 1 stack of Vulnerability<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Earth</span><br>At the Start of the Fight, become Steadfast for 3 turns<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Fire</span><br>At the Start of the Fight, inflict Burn on the enemy</div>',
    'MODIFIER_TOOLTIP_STAVES5': '<div class="text-center"><span class="text-success font-weight-bold">Air</span><br>+20% Dmg Dealt when enemy HP is ≤50%<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Water</span><br>+10% Dmg Dealt When Player HP is ≥50% and Heal for 10% Max HP on Evade<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Earth</span><br>+20% Chance to Ignore Fear, Sleep, Slow, and Stun, and +10% Dmg Dealt to Bleeding Targets<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Fire</span><br>10% Chance on Hit to inflict Burn Vulnerability to the enemy (x2 Dmg Taken from Burn)</div>',
    'MENU_TOOLTIPS_ARTEFACTS5': '<div class="text-center"><span class="text-success font-weight-bold">Triple-triple-charge</span><br>All effect damage and modifier values are amplified by 9×</div>',

    'WTM_EFFECT_TOOLTIP_SYNCRONIZE': 'At max stacks, below effects activate',
    'WTM_EFFECT_TOOLTIP_STRAIGHTSHOOTER': "Next attack is unavoidable and will Crit",
    'WTM_EFFECT_TOOLTIP_SHROUDED': "You are veiled in shadow",



    'MENU_DANGER_ZONE': 'Danger Zone',
    'MENU_SETTINGS_WEAPONS_SECTION': 'Weapon Type & XP Settings',
    'MENU_TEXT_TYPE': "Type",
    'MENU_WEP_MAXED': 'This Weapon\'s Mastery is Maxed <br> It will not gain or contribute further Mastery XP',
    'MENU_NO_WEAPON': 'No weapon Equipped',
    'MENU_BACK': 'Back',
    'MENU_TOGGLE_TYPES': "Toggle Weapon Type Progress",
    'MENU_WEAPON_TYPES': 'Weapon Types',
    'MENU_PERMANENT': '[Permanent]',
    'MENU_EQUIPPED': '[Equipped]',
    'MENU_EQUIPPED_TOOLTIP': 'This Weapon Mastery Bonus only applies while the Mastered Weapon is equipped',
    'MENU_PERMANENT_TOOLTIP': 'This Weapon Mastery Bonus always applies and stacks with each Mastered Weapon',
    'MENU_OVERTITLE': 'Weapon Types × Mastery',
    'MENU_TOOLTIP_INTRO0': 'Welcome to WTM!',
    'MENU_TOOLTIP_INTRO1': 'WTM uses Weapon Stats to calculate Weapon Mastery XP',
    'MENU_TOOLTIP_INTRO2': 'You can use your Weapon Stats to determine starting Weapon Mastery XP, or delete them to start with a clean slate',
    'MENU_TOOLTIP_INTRO3': 'You can delete stats at any point in the Mod Settings',
    'MENU_WARNING': 'Are you sure?',
    'MENU_UPGRADE_TYPE': 'Further Construct your ${fixImg}${fixName} to Unlock',
    'MENU_TYPEPROF_TOOLTIP': 'Proficiency with a Type grows as more weapons of that Type are Mastered',
    'MENU_WARNING1': 'This will delete your existing Weapon Stats',
    'MENU_WARNING15': '(E.g. Total Attacks and Enemies Killed stats)',
    'MENU_WARNING2': 'This action cannot be undone!',
    'MENU_WARNING3': 'This will restart the game',
    'MENU_TYPE_PROF': 'Type Proficiency:',
    'MENU_WEAPON_BONUS': 'Weapon Mastery Bonus',
    'MENU_GLOBAL_APPLIC': 'Always Active',
    'MENU_TYPE_APPLIC': 'Only Active when using Weapons of this Type',
    'MENU_HELP1': 'Did you know?',
    'MENU_HELP2': 'You can hover over elements to learn more!',
    'MENU_SETTINGS_TYPE': 'Types & XP',
    'MENU_POPUP_AGREE': 'Determine my Stats',
    'MENU_POPUP_GODELETE': 'Reset my Stats',
    'MENU_POPUP_DELETEFINAL': 'Reset all Weapon stats',
    'MENU_POPUP_BACK': 'Back',
    'MENU_UNIQ_TOOLTIP': 'Weapon Uniqueness <br> More unique weapons can be trained for longer and provide more Mastery XP until they are Mastered. <br> Uniqueness is based on rarity, and has no relation to strength.',
    'MENU_SETTINGS_NOXP': 'Types & No XP',
    'MENU_SETTINGS_NONE': 'No Types & No XP',
    'MENU_SETTINGS_HOVER_TYPE': "Weapons have Types and can train and can be trained to receive and contribute Mastery XP",
    'MENU_SETTINGS_HOVER_NOXP': "Weapons have Types but cannot be trained to receive and contribute Mastery XP",
    'MENU_SETTINGS_HOVER_NONE': "Weapons do not have Types",

    'WTM_PARRY': "Parry!",
    'WTM_PARRY_CHANCE': "Parry chance",
    'COMBAT_EFFECT_NAME_ Disarm': "Disarm",
    'COMBAT_EFFECT_NAME_ DuelingStance': "DuelingStance",
    'COMBAT_EFFECT_NAME_ WaterHeal': "Refreshing Rain",
    'COMBAT_EFFECT_NAME_ BurnVulnerability': "Burn Vulnerability",
    'COMBAT_EFFECT_NAME_ Terrify': "Terrify",
    'COMBAT_EFFECT_NAME_ Steadfast': "Steadfast",
    'COMBAT_EFFECT_NAME_ AuraAir': "Wind Aura",
    'COMBAT_EFFECT_NAME_ AuraWater': "Chilled Aura",
    'COMBAT_EFFECT_NAME_ AuraEarth': "Earthen Aura",
    'COMBAT_EFFECT_NAME_ AuraFire': "Burning Aura",
    'COMBAT_EFFECT_NAME_ AttunementAir': "Elemental Attunement — Air",
    'COMBAT_EFFECT_NAME_ AttunementWater': "Elemental Attunement — Water",
    'COMBAT_EFFECT_NAME_ AttunementEarth': "Elemental Attunement — Earth",
    'COMBAT_EFFECT_NAME_ AttunementFire': "Elemental Attunement — Fire",
    'COMBAT_EFFECT_NAME_ Volley': "Volley",
    'COMBAT_EFFECT_NAME_ SlinkIntoShadows': "Slink Into Shadows",
    'COMBAT_EFFECT_NAME_ DOTVulnerability': "Overextended",
    'COMBAT_EFFECT_NAME_ TakeAim0': "Take Aim",
    'COMBAT_EFFECT_NAME_ StraightShooter': "Straight Shooter",
    'COMBAT_EFFECT_NAME_ BarbaricStrength': "Barbaric Strength",
    'COMBAT_EFFECT_NAME_ Deadfire': "Deadfire",
    'COMBAT_EFFECT_NAME_ SpikedCarapace0': "Spiked Carapace",
    'COMBAT_EFFECT_NAME_ CycloneFist0': "Cyclone Fist",
    'COMBAT_EFFECT_NAME_ Daze': "Daze",
    'COMBAT_EFFECT_NAME_ PracticedLunge0': "Practiced Lunge",
    'COMBAT_EFFECT_NAME_ DuelingStance': "Dueling Stance",
    'COMBAT_EFFECT_NAME_ Disarm': "Disarmed",
    'COMBAT_EFFECT_NAME_ Intimidation': "Intimidation",
    'COMBAT_EFFECT_NAME_ Shaken': "Shaken",
    'COMBAT_EFFECT_NAME_ Terrify': "Terrify",
    'COMBAT_EFFECT_NAME_ WhirlingManoeuvre0': "Whirling Manoeuvre",
    'COMBAT_EFFECT_NAME_ BloodlustEnemy': "Bloodlust",
    'COMBAT_EFFECT_NAME_ BloodlustPlayer': "Bloodlust",
    'COMBAT_EFFECT_NAME_ Hemorrhage': "Hemorrhage",
    'COMBAT_EFFECT_NAME_ Certainty': "Poise",
    'COMBAT_EFFECT_NAME_ Swiftness': "Swiftness",
    'COMBAT_EFFECT_NAME_ Alacrity': "Alacrity",
    'COMBAT_EFFECT_NAME_ Concentration': "Concentration",
    'COMBAT_EFFECT_NAME_ ZephyrSpeed': "Zephyr Speed",
    'COMBAT_EFFECT_NAME_ Advantage': "Advantage",
    'COMBAT_EFFECT_NAME_ Vulnerability': "Vulnerability",
    'COMBAT_EFFECT_NAME_ Fortified': "Fortified",
    'COMBAT_EFFECT_NAME_ Broken': "Broken",
    'COMBAT_EFFECT_NAME_ ResistanceDecrease': "Resistance Decreased",
    'COMBAT_EFFECT_NAME_ Hobbled': "Hobbled",
    'COMBAT_EFFECT_NAME_ Impact': "Impact",
    'COMBAT_EFFECT_NAME_ Immobilize': "Immobilize",
    'COMBAT_EFFECT_NAME_ Shrouded': "Shrouded",
    'COMBAT_EFFECT_NAME_ Blindsiding': "Blindsiding",
    'COMBAT_EFFECT_NAME_ TheDrop': "The Drop",
    'COMBAT_EFFECT_NAME_ Arrowstruck': "Pinned",
    'COMBAT_EFFECT_NAME_ TranqArrow': "Tranquilizer Arrow",
    'COMBAT_EFFECT_NAME_ PoisonArrow': "Poison Arrow",
    'COMBAT_EFFECT_NAME_ BarbedArrow': "Rupture Arrow",
    'COMBAT_EFFECT_NAME_ FlameArrow': "Flame Arrow",
    'COMBAT_EFFECT_NAME_ NullArrow': "Nullify Arrow",
    'COMBAT_EFFECT_NAME_ SmokeArrow': "Toxic Smoke Arrow",
    'COMBAT_EFFECT_NAME_ PowerStance': "Hunter Stance",


























    'COMBAT_EFFECTGROUP_NAME_ AttunementAir': "Elemental Attunement — Air",
    'COMBAT_EFFECTGROUP_NAME_ AttunementWater': "Elemental Attunement — Water",
    'COMBAT_EFFECTGROUP_NAME_ AttunementEarth': "Elemental Attunement — Earth",
    'COMBAT_EFFECTGROUP_NAME_ AttunementFire': "Elemental Attunement — Fire",
    'COMBAT_EFFECTGROUP_NAME_ Intimidation': "Intimidation",
    'COMBAT_EFFECTGROUP_NAME_ Terrify': "Terrify",
    'COMBAT_EFFECTGROUP_NAME_ Daze': "Daze",
    'COMBAT_EFFECTGROUP_NAME_ LBowDebuffs': "Infused Arrows",


    'SPECIAL_ATTACK_NAME_ ChannelledPalmStrike': "Channeled Palm Strike",
    'SPECIAL_ATTACK_NAME_ Barrage': "Barrage",
    'SPECIAL_ATTACK_NAME_ TakeAim': "Take Aim",
    'SPECIAL_ATTACK_NAME_ BigSmash': "Big Smash",
    'SPECIAL_ATTACK_NAME_ Eradication': "Eradication",
    'SPECIAL_ATTACK_NAME_ RelentlessFury': "Relentless Fury",
    'SPECIAL_ATTACK_NAME_ BarrageOfFlamingDeath': "Barrage of Flaming Death",
    'SPECIAL_ATTACK_NAME_ SpikedCarapace': "Spiked Carapace",
    'SPECIAL_ATTACK_NAME_ Stonewall': "Stonewall",
    'SPECIAL_ATTACK_NAME_ LichsMadness': "Lich's Madness",
    'SPECIAL_ATTACK_NAME_ FistOfTheWinterWinds': "Fist of the Winter Winds",
    'SPECIAL_ATTACK_NAME_ ToxicNeedleFlurry': "Toxic Needle Flurry",
    'SPECIAL_ATTACK_NAME_ CycloneFist': "Cyclone Fist",
    'SPECIAL_ATTACK_NAME_ Shatterstrikes': "Shatterstrikes",
    'SPECIAL_ATTACK_NAME_ CrystalStrike': "Crystal Strike",
    'SPECIAL_ATTACK_NAME_ MountedStrike': "Mounted Strike",
    'SPECIAL_ATTACK_NAME_ PandorasSpark': "Pandora's spark",
    'SPECIAL_ATTACK_NAME_ ConcussiveSmash': "Concussive Smash",
    'SPECIAL_ATTACK_NAME_ DevastatingSlice': "Devastating Slice",
    'SPECIAL_ATTACK_NAME_ PracticedLunge': "Practiced Lunge",
    'SPECIAL_ATTACK_NAME_ WhirlingManoeuvre': "Whirling Manoeuvre",
    'SPECIAL_ATTACK_NAME_ Bloodlust': "Bloodlust",
    'SPECIAL_ATTACK_NAME_ DeathApproaches': "Death Approaches",
    'SPECIAL_ATTACK_NAME_ Blindside': "Blindside",
    'SPECIAL_ATTACK_NAME_ EchoingPalmStrike': "Flowing Palm Wave",
    'SPECIAL_ATTACK_NAME_ MultiShot': "Hail of Arrows",
    'SPECIAL_ATTACK_NAME_ PowerShot': "Killshot",




    'MODIFIER_TOOLTIP_GREAT3': '<div class="text-center"><span class="text-warning font-weight-bold">Devastating Slice (15%)</span><br>Deliver your blade unto the enemy with a wide, arching slash that strikes 2 times for up to 75% of your normal damage per hit.<br> On hit, has a 5% Chance to inflict Shaken for 5 turns.<div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Shaken</span><br>-5% Global Evasion and Resistance</div>',
    'MODIFIER_TOOLTIP_BLUNTS3': '<div class="text-center"><span class="text-warning font-weight-bold">Concussive Smash (30%)</span><br>Smash into your enemy\'s armour, dealing up to 100 + (enemy\'s DR)% Normal damage. Avoidable. <br> Inflicts Daze for 2 turns and has a 20% chance to inflict Broken on a hit.</div>',
    'MODIFIER_TOOLTIP_CURVED3': '<div class="text-center"><span class="text-warning font-weight-bold">Mounted Strike (15%)</span><br>Attack normally, on hit instruct your companions to perform an unavoidable attack each</div>',
    'MODIFIER_TOOLTIP_CROSS3': '<div class="text-center"><span class="text-warning font-weight-bold">Take Aim (15%)</span><br>You find solid supports to brace your crossbow, gaining +15% of Maximum Hit added to Minimum Hit for 3 turns.<br> If buff is already active, perform a regular attack instead.</div>',
    'MODIFIER_TOOLTIP_HTH3': '<div class="text-center"><span class="text-warning font-weight-bold">Channeled Palm Strike (10%)</span><br>Channel your inner strength and perform an avoidable normal attack. Deals 100% of your normal damage and inflicts Stun on the enemy for 1 turn on hit.</div>',
    'MENU_TOOLTIPS_ARTEFACTS3': '<div class="text-center"><span class="text-warning font-weight-bold">Pandora\'s Spark (15%)</span><br><span>Inflict a Triple-charged random effect on yourself and the enemy</span><div class="col-12 mb-1 dropdown-divider"></div><span class="text-success font-weight-bold">Triple-charge</span><br><span>All effect damage and modifier values are amplified by 3×</span></div>',
    'MODIFIER_TOOLTIP_THRUSTING3': '<div class="text-center"><span class="text-warning font-weight-bold">Practiced Lunge (15%)</span><br>Perform an unavoidable lunge that ignores enemy Resistance. Deals 50% Normal Damage</div>',
    'MODIFIER_TOOLTIP_DAGGER3': '<div class="text-center"><span class="text-warning font-weight-bold">Blindside (15%)</span><br>Exploit the enemy\'s blind spots.<br>Deal 1 + (Stealth/50) strikes, dealing 75% of your Normal damage. <br> Strikes have +30% critical hit multiplier.</div>',
    'MODIFIER_TOOLTIP_HTH5': '<div class="text-center"><span class="text-warning font-weight-bold">Flowing Palm Wave (10%)</span><br>Unleash a flurry of blows with your inner energy. Strikes 2 times, or 5 times if unburdened. <br> Deals 50% of your normal damage and has a 10% chance to Stun the Enemy for 2 turns on hit.</div>',
    'MODIFIER_TOOLTIP_LIGHT3': '<div class="text-center"><span class="text-warning font-weight-bold">Hail of Arrows (25%)</span><br>Let loose a hail of 10 arrows aimed around the Enemy, each dealing 15% of your normal damage on hit.</div>',


    'SPECIAL_ATTACK_DESC_ DeathApproaches': "Strike your enemy's weak spot, dealing ${attackDamageMaxValue0}% of their max HP.",
    'SPECIAL_ATTACK_DESC_ PracticedLunge': "Perform an unavoidable lunge that ignores enemy Resistance. Deals ${attackDamageMaxValue0}% normal damage.",
    'SPECIAL_ATTACK_DESC_ Bloodlust': "Let out a bloodcurdling warcry. Gain 1 stack of Bloodlust which gives you: +${preHitEffect0modValue0}% Lifesteal, +${preHitEffect0modValue1}% Max Hit, +${preHitEffect0modValue2} Flat Damage to Bleeding targets, -${preHitEffect0modValue3}% Attack Interval, and +${preHitEffect0modValue4}% Self Damage on Hit.<br> Each stack of Bloodlust also gives the enemy +${preHitEffect1modValue0}% Bleed Damage Taken, -${preHitEffect1modValue1}% Max Hit, -${preHitEffect1modValue2}% Resistance, and +${preHitEffect1modValue3}% Attack Interval.",
    'SPECIAL_ATTACK_DESC_ PandorasSpark': "Inflict a Triple-charged random effect on yourself and the enemy",
    'SPECIAL_ATTACK_DESC_ MountedStrike': "Attack normally, on hit instruct your companions to perform an unavoidable attack each.",
    'SPECIAL_ATTACK_DESC_ ConcussiveSmash': "Smash into your enemy's armour, dealing up to (100 + enemy DR)% Normal damage.<br> On a hit, inflicts Daze for 2 turns and has a ${onHitEffect1chance}% chance to inflict Broken. Avoidable.",
    'SPECIAL_ATTACK_DESC_ DevastatingSlice': "Deliver your blade unto the enemy with a wide, arching slash that strikes ${hitCount} times for up to ${attackDamageMaxValue0}% of your normal damage per hit. <br> On hit, has a ${onHitEffect0chance}% Chance to inflict Shaken (-${onHitEffect0modValue}% Global Evasion and -${onHitEffect0modValue1}% Total Resistance on the enemy for ${onHitEffect0turns} turns).",
    'SPECIAL_ATTACK_DESC_ ChannelledPalmStrike': "Channel your inner strength and perform an avoidable normal attack. Deals ${attackDamageMaxValue0}% of your normal damage and has a ${onHitEffect0chance}% chance to Stun the enemy for ${onHitEffect0turns} turn on hit.",
    'SPECIAL_ATTACK_DESC_ TakeAim': "You find solid supports to brace your crossbow, gaining +${preHitEffect0modValue0}% of Maximum Hit added to Minimum Hit for ${preHitEffect0turns} turns.<br> If buff is already active, perform a regular attack instead.",
    'SPECIAL_ATTACK_DESC_ BigSmash': "Smash the enemy for ${attackDamageMaxValue0}% of your normal damage. If you hit, you gain Barbaric Strength, giving you ${onHitEffect0modValue} stacking Flat Melee Max Hit until the End of the Fight.",
    'SPECIAL_ATTACK_DESC_ Eradication': "You snuff the life force out of the enemy, dealing damage equal to ${attackDamageMaxValue0}%-${attackDamageMaxValue1}% of their current HP, and heal for ${lifesteal}% of the damage dealt.<br> Uses Prayer Points.",
    'SPECIAL_ATTACK_DESC_ RelentlessFury': "Make ${hitCount} attacks, each dealing a small percentage of your Maximum Hit: 1st—${attackDamageMaxValue0}%; 2nd—${attackDamageMaxValue1}%; 3rd—${attackDamageMaxValue2}%; 4th—${attackDamageMaxValue3}%; and 5th—${attackDamageMaxValue4}%. Each hit has a ${onHitEffect0chance}% chance to decrease your Damage Reduction by ${onHitEffect0modValue}% for the rest of the fight and to inflict a 1-turn Stun on the enemy.",
    'SPECIAL_ATTACK_DESC_ BarrageOfFlamingDeath': "Your fists take on an aspect of the eternal flame, Ragnar. Make ${hitCount} attacks, each dealing a small percentage of your Maximum Hit: 1st—${attackDamageMaxValue0}%; 2nd—${attackDamageMaxValue1}%; 3rd—${attackDamageMaxValue2}%; and 4th—${attackDamageMaxValue3}%. Each hit has a ${onHitEffect0chance}% chance (doubled if the enemy is Burning) to inflict Deadfire, a powerful Burn that deals ${onHitEffect0DamageMaxValue0}% of the enemy's current hitpoints as damage over ${onHitEffect0duration}s.",
    'SPECIAL_ATTACK_DESC_ SpikedCarapace': "Your gloves instantly grow to become a spiky shell around your body for ${preHitEffect0turns} turns. While protected by this carapace, you have +${preHitEffect0modValue0}% Reflect Damage, +${preHitEffect0modValue1}% chance to ignore Slow Effects, and +${preHitEffect0modValue2}% Flat Damage Reduction.<br> If this buff is already active, make a normal attack instead.",
    'SPECIAL_ATTACK_DESC_ Stonewall': "Driving your fists into the rocky earth, you conjure a stone barrier, granting you +${preHitEffect0modValue0}% Flat Damage Reduction for ${preHitEffect0turns} turns. <br> Then hurl the stone at the enemy, dealing damage equal to ${attackDamageMaxValue0}%-${attackDamageMaxValue1}% of your Defence level. Unavoidable.",
    'SPECIAL_ATTACK_DESC_ LichsMadness': "Engulf yourself in umbral flame while your extremities turn to jet ice shards, inflicting Burn and Frostburn on yourself, then strike ${hitCount} times.<br> On the 1st attack, deal ${attackDamageMaxValue0}% of your normal (doubled if enemy is Burning).<br> On the 2nd and 3rd attacks, deal damage equal to ${attackDamageMaxValue1} + ${attackDamageMaxValue2}% of your Magic level.<br> Each hit has a ${onHitEffect0chance}% chance to inflict Burn which deals ${onHitEffect0DamageMaxValue0}% of the enemy's current hitpoints as damage over ${onHitEffect0duration}s, and Frostburn for ${onHitEffect2turns} turns.",
    'SPECIAL_ATTACK_DESC_ ToxicNeedleFlurry': "Fire ${hitCount} small needles from your knuckles in a flurry that deal up to ${attackDamageMaxValue0}% of your normal damage each (Avoidable).<br> On a hit has a ${onHitEffect0chance}% chance to inflict Poison that deals ${onHitEffect0DamageMaxValue0}% of the enemy's max hitpoints as damage over ${onHitEffect0duration}s.",
    'SPECIAL_ATTACK_DESC_ CycloneFist': "Surround yourself in wind for ${duration}s, while dealing ${attackDamageMaxValue0}% normal damage ${hitCount} times. Grants +${preHitEffect0modValue0}% Global Evasion and +${preHitEffect0modValue1} Flat Reflect Damage until the end of the attack. Avoidable.",
    'SPECIAL_ATTACK_DESC_ Shatterstrikes': "Harnessing crystalline power, make two swift strikes against the Target, each dealing ${attackDamageMaxValue0}% your maximum hit (doubled if the enemy is Crystallized).<br> On hit, ${onHitEffect0chance}% chance to apply Crystallization (Target is stunned and takes +50% Damage) for ${onHitEffect0turns} turn(s), and ${onHitEffect1chance}% chance to apply Crystal Sanction (Target's next attack deals no damage).",
    'SPECIAL_ATTACK_DESC_ CrystalStrike': "Focus crystalline energy into your knuckles to land a powerful strike.<br> On hit, deals ${attackDamageMaxValue0}% of your normal damage and has a ${onHitEffect0chance}% chance to apply Crystallization (Target is stunned and takes +50% Damage) for 1 turn.",
    'SPECIAL_ATTACK_DESC_ WhirlingManoeuvre': "Whirl your polearm around, attacking ${hitCount} times for ${attackDamageMaxValue0}% of your normal damage each.<br> While attacking, gain +${preHitEffect0modValue1}% Dodge Chance and reflect enemy attacks for ${preHitEffect0modValue0}% of their damage.",
    'SPECIAL_ATTACK_DESC_ Blindside': "Exploit the enemy's blind spots, attacking ${hitCount} ( 1 + (Stealth/50) ) times. <br> Strikes deal ${attackDamageMaxValue0}% of your Normal damage and have +${preHitEffect0modValue0}% critical hit multiplier.",
    'SPECIAL_ATTACK_DESC_ EchoingPalmStrike': "Unleash a flurry of blows with your inner energy. Strikes ${hitCount} times (more if unburdened). <br> Deals ${attackDamageMaxValue0}% of your normal damage and has a ${onHitEffect0chance}% chance to Stun the Enemy for ${onHitEffect0turns} turns on hit.",
    'SPECIAL_ATTACK_DESC_ MultiShot': "Let loose a hail of ${hitCount} arrows aimed around the Enemy, each dealing ${attackDamageMaxValue0}% of your normal damage on hit.",
    'SPECIAL_ATTACK_DESC_ PowerShot': "You loose a single fatal arrow with absolute certainty, dealing damage equal to ${attackDamageMinValue0}% to ${attackDamageMaxValue0}% of their DR. <br> If your Accuracy Rating is higher than ${minAccuracy} then this attack can't miss.<br> On a hit, inflict 1 stack of Pinned (+${onHitEffect0modValue0}% Attack Interval and +${onHitEffect0modValue1}% Damage Taken per stack, max 10 stacks) Damage Taken. Lasts until the End of the Fight.",

    'MENU_SETTINGS_TOOLTIP': 'Whether this Namespace\'s weapons should have Types or gain and contribute XP',


    'WTM_UNIQ_No_XP': 'No XP',
    'WTM_UNIQ_Stock': 'Stock',
    'WTM_UNIQ_Unusual': 'Unusual',
    'WTM_UNIQ_Distinct': 'Distinct',
    'WTM_UNIQ_Exotic': 'Exotic',
    'WTM_UNIQ_Exotic+': "Exotic+",
    "WTM_WEAPON_NAME_HandToHand": "Hand-to-Hand",
    "WTM_WEAPON_NAME_Blunts": "Bludgeoning Weapons",
    "WTM_WEAPON_NAME_ThrustingSwords": "Thrusting Swords",
    "WTM_WEAPON_NAME_Greatswords": "Greatswords",
    "WTM_WEAPON_NAME_CurvedSwords": "Curved Swords",
    "WTM_WEAPON_NAME_Daggers": "Daggers",
    "WTM_WEAPON_NAME_Axes": "Axes",
    "WTM_WEAPON_NAME_Polearms": "Polearms",
    "WTM_WEAPON_NAME_Blunts": "Bludgeoning Weapons",
    "WTM_WEAPON_NAME_Crossbows": "Crossbows",
    "WTM_WEAPON_NAME_HeavyBows": "Heavy Bows",
    "WTM_WEAPON_NAME_LightBows": "Light Bows",
    "WTM_WEAPON_NAME_Thrown": "Thrown",
    "WTM_WEAPON_NAME_Staves": "Staves",
    "WTM_WEAPON_NAME_Wands": "Wands",
    "WTM_WEAPON_NAME_Wands": "Wands",
    "WTM_WEAPON_NAME_Artefacts": "Artefacts",
    "WTM_WEAPON_NAME_Special": "Tools",

    "WTM_WEAPON_FLAVORTEXT_ThrustingSwords": "Light and well-balanced for flying past the opponent's guard",
    "WTM_WEAPON_FLAVORTEXT_Greatswords": "Simply brutal and brutally simple",
    "WTM_WEAPON_FLAVORTEXT_CurvedSwords": "Dancing blades that embolden one's allies",
    "WTM_WEAPON_FLAVORTEXT_Daggers": "Light and fatal, they disappear from their owner's hand and reappear in their targets' backs",
    "WTM_WEAPON_FLAVORTEXT_Axes": "Violent and with a thirst for blood, axes grow in power as the battle rages",
    "WTM_WEAPON_FLAVORTEXT_Polearms": "Designed to land mildly-dangerous strikes at a mildly-safe distance",
    "WTM_WEAPON_FLAVORTEXT_Blunts": "Specialized in breaking through defenses and leaving their victims reeling",
    "WTM_WEAPON_FLAVORTEXT_HandToHand": "Free from weapons or heavy armor, one's own body becomes a fleet and deadly weapon",
    "WTM_WEAPON_FLAVORTEXT_Crossbows": "Sacrifice speed for absolute accuracy and overwhelming strength",
    "WTM_WEAPON_FLAVORTEXT_HeavyBows": "Unerring, powerful instruments meant to find the weakness in their foes",
    "WTM_WEAPON_FLAVORTEXT_LightBows": "Evasive bows meant to pelt attackers with arrows while staying out of harm's way",
    "WTM_WEAPON_FLAVORTEXT_Thrown": "If the first one misses, the next five won't",
    "WTM_WEAPON_FLAVORTEXT_Staves": "Elementally-attuned kaleidoscopic tools of the arcane",
    "WTM_WEAPON_FLAVORTEXT_Wands": "Defensive, general magical implements for the wary wizard",
    "WTM_WEAPON_FLAVORTEXT_Artefacts": "Instruments representing Magic at its ficklest, to be used with great care and greater caution",
    "WTM_WEAPON_FLAVORTEXT_Special": "Made for chores and not for combat, it's debatable whether these are even weapons",
    "WTM_MAX": "MAX"











}    
