const { loadModule } = mod.getContext(import.meta);

const { WeaponTypeCondition } = await loadModule('src/patches/patches/weaponMastery/weaponTypeCondition.mjs');
const { EmptySlotCondition } = await loadModule('src/patches/patches/EmptySlotCondition.mjs');
const { WeaponCondition } = await loadModule('src/patches/patches/weaponMastery/weaponCondition.mjs');


const { getRielkLangString } = await loadModule('src/language/translationManager.mjs');


export function patchConditionalMod(ctx) {
  const original = ConditionalModifier.getCombatConditionFromData;

  ConditionalModifier.getCombatConditionFromData = function (data, game) {
    if (data.type === 'WeaponType')
      return new WeaponTypeCondition(data, game);
    if (data.type === 'Weapon')
      return new WeaponCondition(data, game);
    if (data.type === 'EmptySlot')
      return new EmptySlotCondition(data, game);
    return original.call(this, data, game);
  };



  ctx.patch(Character, "checkEffectApplicatorCondition").after(function (ret, condition, source) {
    if (condition instanceof WeaponTypeCondition)
      return condition.checkIfMetForChar(this);
    if (condition instanceof EmptySlotCondition)
      return condition.checkIfMetForChar(this);
  })
}